from ._linear_model import LinearRegression

__all__= ['LinearRegression']
